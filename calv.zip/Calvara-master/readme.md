# Project Calvara
> Presented by [Transaxi Investments](https://transaxi.investments)

Fully featured automated bot capable of trading most types
of securities across multiple brokers. Utilizing the power of
multiple algorithmic strategies, this project is designed to
be as efficient as possible at opening/closing positions at
the perfect time. 

## Installation
Install all Python dependencies that are required by this project
> This task can be done automatically by executing `./cmd.sh --update`
```
# Install Python Requirements
~$ python -m pip install --upgrade pip # optional
~$ python -m pip install -r app/requirements.txt
```

## Deployment
Change into the 'app' directory
`~$ cd app/`

**Flask Server Application** ([app.py](app/app.py))
- Communicate with brokers API system
- Listen for webhooks/callbacks from TV
```
# Initialize Development Environment & Launch Flask Application
~$ export FLASK_DEBUG=true
~$ flask run

# Test Connectivity / Functionality
~$ curl -X POST --data '{"signal": "test", "security": "test"}' -H "Content-Type: application/json" http://localhost:5000/TVWebhook
```
It is recommended to execute these command in order to setup the initial
working environment, though afterwards you can start the listening server
in the background automatically using `./cmd.sh --launch`

**Calvara Application** ([calvara.py](app/calvara.py))
- Initial Authentication & Configuration
- Communication Proxy to Flask App (optional)
```
~$ python ./calvara.py
```
