#! /usr/bin/env python

import calvaralib
import sys, tda, json

cllogger = calvaralib.LogCore()
clutil = calvaralib.UtilCore()

cltda = calvaralib.TDACore()
clmeta = calvaralib.MetaCore()

calvaralib.__verbose__ = True

if __name__ == '__main__':
	clutil.print_info("Calvara Testing Module")

	# tradeObj = clmeta.openPosition("ebd03dc4-ad28-4d00-8584-236261c6a2c2", "SELL", "XAUUSD")
	tradeObj = clmeta.closePositions("ebd03dc4-ad28-4d00-8584-236261c6a2c2", "XAUUSD")
	print(tradeObj)

	sys.exit(0)

	try:
		metaAccList = clmeta.buildAPIRequest("PROVISIONING", "/users/current/accounts")
		# print(clmeta.buildAPIRequest("PROVISIONING", "/users/current/provisioning-profiles"))

		print(metaAccList)
		clutil.print_success("Found %s account(s)!\n" % str(len(metaAccList)))

		accountPosition = 1
		for metaAccount in metaAccList:
			print("{1}) {2}:{3} ({4}) | [{0}]".format(metaAccount["state"], accountPosition, metaAccount["userName"], metaAccount["login"], metaAccount["server"]))
			accountPosition += 1
	except Exception as e:
		clutil.print_error("Failed => %s" % e)

	print()
	targetAccount = int(input("Choose Account => ")) - 1
	# metaAccObj = clmeta.buildAPIRequest("MANAGER", "/users/current/mt4/provisioning-profiles/{0}/accounts/{1}/accountInformation".format(metaAccList[targetAccount]["_id"], metaAccList[targetAccount]["login"]))
	print(metaAccObj)

	# place trade
	# /users/current/accounts/{accountId}/trade
	tradeObj = clmeta.openPosition("ebd03dc4-ad28-4d00-8584-236261c6a2c2")