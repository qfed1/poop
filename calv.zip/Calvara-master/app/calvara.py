#! /usr/bin/env python
""" Calvara """

import calvaralib
import tda, json, httpx, argparse

# Define CLI Arguments
argsToParse = argparse.ArgumentParser(description="Calvara | Transaxi Investments")

switchArgGroup = argsToParse.add_argument_group("[switches]")
switchArgGroup.add_argument("-v", "--verbose", action="store_true", help="stdout DEBUG responses")
switchArgGroup.add_argument("--update", action="store_true", help="pull latest updates from git repo")

cmdArgGroup = argsToParse.add_argument_group("[stdin utility]")
cmdArgGroup.add_argument("-b", "--backtest")
cmdArgGroup.add_argument("-m", "--monitor")

# Initialize Core Libraries
flutil = calvaralib.UtilCore()
fltda = calvaralib.TDACore()

# Initialize Variables
argParsedObj = argsToParse.parse_args()
calvaralib.__verbose__ = argParsedObj.verbose

if __name__ == '__main__':
	flutil.print_info("Welcome to Calvara, presented by Transaxi Investments")
	print()

	# TDA API Authentication
	tdaAuthObj = None
	flutil.print_info("Logging into TD Ameritrade..")
	try:
		tdaAuthObj = tda.auth.client_from_token_file(calvaralib.__config__["TDA_API"]["TDA_TOKEN_FILE"], calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"])
	except Exception:
		tdaAuthObj = tda.auth.client_from_manual_flow(calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"], calvaralib.__config__["TDA_API"]["TDA_REDIRECT_URL"], calvaralib.__config__["TDA_API"]["TDA_TOKEN_FILE"])

	accountListObj = json.loads(tdaAuthObj.get_accounts().text)

	flutil.print_success("Logged in as {0} ({1} account)".format(accountListObj[0]["securitiesAccount"]["accountId"], accountListObj[0]["securitiesAccount"]["type"]))
	flutil.print_info("Balances => Initial Bankroll: ${0} | Current Bankroll: ${1}".format(accountListObj[0]["securitiesAccount"]["initialBalances"]["cashBalance"], accountListObj[0]["securitiesAccount"]["currentBalances"]["cashBalance"]))
	# flutil.print_info("Cash Available 4 Withdrawal: $%s" % accountListObj[0]["securitiesAccount"]["projectedBalances"]["cashAvailableForWithdrawal"])

	"""
	{
		"securitiesAccount": {
			"type": "CASH",
			"accountId": "255604755",
			"roundTrips": 0,
			"isDayTrader": false,
			"isClosingOnlyRestricted": false,
			"initialBalances": {
				"accruedInterest": 0,
				"cashAvailableForTrading": 0,
				"cashAvailableForWithdrawal": 0,
				"cashBalance": 0,
				"bondValue": 0,
				"cashReceipts": 0,
				"liquidationValue": 0,
				"longOptionMarketValue": 0,
				"longStockValue": 0,
				"moneyMarketFund": 0,
				"mutualFundValue": 0,
				"shortOptionMarketValue": 0,
				"shortStockValue": 0,
				"isInCall": false,
				"unsettledCash": 0,
				"cashDebitCallValue": 0,
				"pendingDeposits": 0,
				"accountValue": 0
			},
			"currentBalances": {
				"accruedInterest": 0,
				"cashBalance": 0,
				"cashReceipts": 0,
				"longOptionMarketValue": 0,
				"liquidationValue": 0,
				"longMarketValue": 0,
				"moneyMarketFund": 0,
				"savings": 0,
				"shortMarketValue": 0,
				"pendingDeposits": 0,
				"cashAvailableForTrading": 0,
				"cashAvailableForWithdrawal": 0,
				"cashCall": 0,
				"longNonMarginableMarketValue": 0,
				"totalCash": 0,
				"shortOptionMarketValue": 0,
				"mutualFundValue": 0,
				"bondValue": 0,
				"cashDebitCallValue": 0,
				"unsettledCash": 0
			},
			"projectedBalances": {
				"cashAvailableForTrading": 0,
				"cashAvailableForWithdrawal": 0
			}
		}
	}
	"""
