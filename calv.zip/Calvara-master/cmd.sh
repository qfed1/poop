# Starting Module for FuturisticTrader
echo -- FuturisticTrader Command Module --
echo

# Execution Options
# ./cmd.sh --update
# ./cmd.sh --launch

# Update Everything!
if [[ $1 == "--help" ]]; then
	echo This module may be executed with 3 switches.
	echo
	echo --help	\	\	Display this help menu
	echo --update \	Update system and application dependencies
	echo --launch \	Launch Flask server and Futureistic app
elif [[ $1 == "--update" ]]; then
	echo Installing Dependencies..
	sleep 3
	echo

	echo Updating System..
	sudo apt update; sudo apt upgrade -y; sudo apt autoremove -y;
	clear

	echo Updating Python Dependencies...
	python -m pip install --upgrade pip
	python -m pip install -r requirements.txt
	clear

	echo Everything is Updated!
elif [[ $1 == "--launch" ]]; then
	cd app/

	echo Starting Flask Server..
	screen -dm bash -c 'flask run'
	echo Flask Server Initialized
	echo
	
	echo All Systems Operational
	echo http://localhost:5000/TVWebhook
	echo
else
	echo Please execute \"./cmd.sh --help\" for more information on how to use this command module.
fi
