#! /usr/bin/env python

import calvaralib
import sys, json, urllib, requests

class TDACore(object):
	"""
		CalvaraLib | TDACore
	"""

	def __init__(self, *args, **kwargs):
		self.TDA_API_URL = calvaralib.__config__["TDA_API"]["TDA_API_URL"]
		self.TDA_CONSUMER_KEY = calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"]
		self.TDA_CALLBACK_URI = calvaralib.__config__["TDA_API"]["TDA_REDIRECT_URL"]

	def buildAPIRequest(reqType, tarEndpoint, tarPayload=None):
		""" TDACore => buildAPIRequest

		[INPUT]
		reqType => [GET|POST]
		tarEndpoint => TDA API Endpoint
		tarPayload => {"": ""}

		[OUTPUT]
		...
		"""
		reqHeaders = {
			"Content-Type": "application/x-www-form-urlencoded"
		}

		if reqType == "GET":
			return requests.get("{0}{1}".format(self.TDA_API_URL, tarEndpoint), headers=reqHeaders)
		elif reqType == "POST":
			if tarPayload != None: return requests.post("{0}{1}".format(self.TDA_API_URL, tarEndpoint), headers=reqHeaders, data=tarPayload)
			else: return requests.post("{0}{1}".format(self.TDA_API_URL, tarEndpoint), headers=reqHeaders)

	def buildAuthURI():
		return "https://auth.tdameritrade.com/auth?response_type=code&redirect_uri={0}&client_id={1}%40AMER.OAUTHAP".format(urllib.parse.urlencode(TDA_CALLBACK_URI), TDA_CONSUMER_KEY)

	def buildAuthPayload(TDA_API_AUTH_CODE):
		""" TDACore => buildAuthPayload

		Retrieve access_token and refresh_token after we've acquired 

		[INPUT]
		TDA_API_AUTH_CODE => Retrieved from callback listener after client approves access via 'TDACore => buildAuthURI'

		[OUTPUT]
		{
			"access_token" : "",
			"refresh_token" : "",
			"scope" : "PlaceTrades AccountAccess MoveMoney",
			"expires_in" : 1800,
			"refresh_token_expires_in" : 7776000,
			"token_type" : "Bearer"
		}		
		"""
		authPayload = {
			"grant_type": "authorization_code",
			"access_type": "offline",
			"code": TDA_API_AUTH_CODE,
			"client_id": self.TDA_CONSUMER_KEY,
			"redirect_uri": self.TDA_CALLBACK_URI
		}
		
		return buildAPIRequest("POST", "/oauth2/token", authPayload).text

		# TDA API Authentication
		def initializeTDAAuthentication():
			tdaAuthObj = None
			flutil.print_info("Logging into TD Ameritrade..")
			try: tdaAuthObj = tda.auth.client_from_token_file("data/tokens.ini", calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"])
			except Exception: tdaAuthObj = tda.auth.client_from_manual_flow(calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"], calvaralib.__config__["TDA_API"]["TDA_REDIRECT_URL"], "config/tokens.ini")
			flutil.print_success("Successfully Authenticated!\n")
			return tdaAuthObj

		def placeTDAOrder(tdaAuthObj, tarSecurity, tradeDirection, tradeQuantity):
			placedOrderObj = tdaAuthObj.place_order(accountListObj[0]["securitiesAccount"]["accountId"], tda.orders.equities.equity_buy_market(tarSecurity, tradeQuantity))
			placedOrderData = json.loads(placedOrderObj.text) # {"error": "Your buying power will be below zero ($187.75) if this order is accepted., OrderId: 5738614225"}

			if placedOrderObj.status_code == 200:
				print(placedOrderObj.text)
			elif placedOrderObj.status_code == 400:
				errorObj = placedOrderData["error"].split(", ")
				flutil.print_error("{0} failed to execute\n{1}".format(errorObj[1], errorObj[0]))