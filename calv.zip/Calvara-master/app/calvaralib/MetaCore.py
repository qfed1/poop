import calvaralib
import json, requests

class MetaCore(object):
    """
        CalvaraLib | MetaCore
    """

    def __init__(self, *args, **kwargs):
        self.clutils = calvaralib.UtilCore()

    def buildAPIRequest(self, apiType, reqType, tarEndpoint, tarPayload=None):
        reqHeaders = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'auth-token': calvaralib.__config__["META_API"]["META_API_TOKEN"]
        }

        if apiType == "PROVISIONING": apiType = "META_PROVISIONING_API_URL"
        elif apiType == "CLIENT": apiType = "META_CLIENT_API_URL"
        elif apiType == "MANAGER": apiType = "META_MANAGER_API_URL"

        if reqType == "GET": reqRes = requests.get("{0}{1}".format(calvaralib.__config__["META_API"][apiType], tarEndpoint), headers=reqHeaders)
        elif reqType == "POST":
            if tarPayload != None: reqRes = requests.post("{0}{1}".format(calvaralib.__config__["META_API"][apiType], tarEndpoint), headers=reqHeaders, data=tarPayload)
            else: reqRes = requests.post("{0}{1}".format(calvaralib.__config__["META_API"][apiType], tarEndpoint), headers=reqHeaders)

        if reqRes.status_code == 200: return json.loads(reqRes.text)
        else:
            reqResObj = json.loads(reqRes.text)
            self.clutils.print_error("Error '{0}' ({1}) =>\n{2}".format(reqResObj["error"], reqResObj["id"], reqResObj["message"]))

    def openPosition(self, tarAccountID, tradeDirection, tradeSymbol):
        # /users/current/accounts/{accountId}/trade
        payloadObj = {
            "actionType": "ORDER_TYPE_BUY" if tradeDirection == "BUY" else "ORDER_TYPE_SELL",
            "symbol": tradeSymbol,
            "volume": 1.00
        }
        
        placedOrderRes = self.buildAPIRequest("CLIENT", "POST", "/users/current/accounts/{0}/trade".format(tarAccountID), tarPayload=json.dumps(payloadObj))
        return placedOrderRes

    def closePositions(self, tarAccountID, tradeSymbol):
        payloadObj = {
            "actionType": "POSITIONS_CLOSE_SYMBOL",
            "symbol": tradeSymbol
        }

        placedOrderRes = self.buildAPIRequest("CLIENT", "POST", "/users/current/accounts/{0}/trade".format(tarAccountID), tarPayload=json.dumps(payloadObj))
        return placedOrderRes

        """
curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'auth-token: token' -d '{
"actionType": "ORDER_TYPE_SELL",
"symbol":"AUDNZD",
"volume": 0.01,
"takeProfit": 1.03
}' 'https://mt-client-api-v1.agiliumtrade.agiliumtrade.ai/users/current/accounts/ebd03dc4-ad28-4d00-8584-236261c6a2c2/trade'


eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiJjYjlmYTc1ODY1ZjEyNmM1ZTE4MDdjZWI0Yzk5ZWMyMiIsInBlcm1pc3Npb25zIjpbXSwidG9rZW5JZCI6IjIwMjEwMjEzIiwiaWF0IjoxNjYwODU2MDI3LCJyZWFsVXNlcklkIjoiY2I5ZmE3NTg2NWYxMjZjNWUxODA3Y2ViNGM5OWVjMjIifQ.GbKL8NFXxN9gK3ZayKzvJ11t-XH-mnx9DaxdS3J7dU6jZ3YdgivqWssxXf3t3MtarBWT4sR-8_lrP0vFwWuP4_aSgvJtm351cM5Ga8rC2j_WrB3XTeTdsb0EFlUVA873L7ilj7kUg92tqbpN4y01RVd6QSshjPZ_De_ggCmX-0xhY84EpQ5WNg9qxzpfMumZrAWwZCFU6jRNSh-09qY8A0Wp7seQLCZKra15Xuy5uziBIMxbgdq8KLIDbaDoseeF-cpmMe5TF6zWti_alCkM8FsNa8if-7XZUjgjO-owHJNi6Uu2YeA5dtMgLB6PMbDrGVRMj8xP3on1BqD7AJpTliRXYoUqTAwEEwtsoV1_to5FEvTxrZ1fijcRcNBlrBZG7R10vlnzXOnLq1Qp3ISnGSGSmDRXEhC9YcSKnWXg9F_Miu6vMhf2HqoJnA99y4oQOM7sPbH9bkhgF9vGZvoDnG4vdR4WM2w9vlSVZDxBcW-20u8FF7lQC5XHOXoFvy7Xk0PRjexHadC-R5t5cAGjSWk8kS9_CJlHRyYf0xd37s0OXtNeeeYznCYLDoc-EZVOC9XcMg90XCgtlLjh6SLmlNndpcbLC2gmRsX7T7n9g5FMOBwYD3aHhaiDvqrcfPfJdnqiNf1ybr2Z-TykVXyo3tqDMRY8CDDshmiIZKGO3vA


curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'auth-token: eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiJjYjlmYTc1ODY1ZjEyNmM1ZTE4MDdjZWI0Yzk5ZWMyMiIsInBlcm1pc3Npb25zIjpbXSwidG9rZW5JZCI6IjIwMjEwMjEzIiwiaWF0IjoxNjYwODU2MDI3LCJyZWFsVXNlcklkIjoiY2I5ZmE3NTg2NWYxMjZjNWUxODA3Y2ViNGM5OWVjMjIifQ.GbKL8NFXxN9gK3ZayKzvJ11t-XH-mnx9DaxdS3J7dU6jZ3YdgivqWssxXf3t3MtarBWT4sR-8_lrP0vFwWuP4_aSgvJtm351cM5Ga8rC2j_WrB3XTeTdsb0EFlUVA873L7ilj7kUg92tqbpN4y01RVd6QSshjPZ_De_ggCmX-0xhY84EpQ5WNg9qxzpfMumZrAWwZCFU6jRNSh-09qY8A0Wp7seQLCZKra15Xuy5uziBIMxbgdq8KLIDbaDoseeF-cpmMe5TF6zWti_alCkM8FsNa8if-7XZUjgjO-owHJNi6Uu2YeA5dtMgLB6PMbDrGVRMj8xP3on1BqD7AJpTliRXYoUqTAwEEwtsoV1_to5FEvTxrZ1fijcRcNBlrBZG7R10vlnzXOnLq1Qp3ISnGSGSmDRXEhC9YcSKnWXg9F_Miu6vMhf2HqoJnA99y4oQOM7sPbH9bkhgF9vGZvoDnG4vdR4WM2w9vlSVZDxBcW-20u8FF7lQC5XHOXoFvy7Xk0PRjexHadC-R5t5cAGjSWk8kS9_CJlHRyYf0xd37s0OXtNeeeYznCYLDoc-EZVOC9XcMg90XCgtlLjh6SLmlNndpcbLC2gmRsX7T7n9g5FMOBwYD3aHhaiDvqrcfPfJdnqiNf1ybr2Z-TykVXyo3tqDMRY8CDDshmiIZKGO3vA' -d '{
"actionType": "ORDER_TYPE_SELL",
"symbol":"AUDNZD",
"volume": 0.01,
"takeProfit": 1.03
}' 'https://mt-client-api-v1.agiliumtrade.agiliumtrade.ai/users/current/accounts/ebd03dc4-ad28-4d00-8584-236261c6a2c2/trade'
        """