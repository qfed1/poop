#! /usr/bin/env python
""" Calvara """

import calvaralib
import json, requests
from flask import Flask, request

# App Configuration
app = Flask("Calvara")
cllogger = calvaralib.LogCore()
clutil = calvaralib.UtilCore()

clmeta = calvaralib.MetaCore()

""" START FLASK APP ENDPOINT DEFINITIONS """

@app.route("/TVWebhook", methods=["POST"])
def webhook():
	""" Calvara Flask Webhook

	[INPUT]

	POST (application/json)
	{
		"signal": "buy" | "sell",
		"security": "NVDA"
	}

	"""
	jsonRespObj = request.get_json()
	metaAccList = clmeta.buildAPIRequest("PROVISIONING", "GET", "/users/current/accounts")

	if jsonRespObj["signal"] == "test":
		print("[TV => TEST] Test Webhook Received!")

		# tdaAuthObj = initializeTDAAuthentication() # Authenticate with TD Ameritrade before we start making API calls

		return "All Systems Operational.\n"

	elif jsonRespObj["signal"] == "buy":
		print("[TV => ⬆️] Placing a BUY order!")

		clmeta.closePositions(metaAccList[0]["_id"], jsonRespObj["security"])
		clmeta.openPosition(metaAccList[0]["_id"], "BUY", jsonRespObj["security"])
		#tdaAuthObj = initializeTDAAuthentication()
		#placeTDAOrder(tdaAuthObj, jsonRespObj["security"], "buy", 1)

	elif jsonRespObj["signal"] == "sell":
		print("[TV => ⬇️] Placing a SELL order!")

		clmeta.closePositions(metaAccList[0]["_id"], jsonRespObj["security"])
		clmeta.openPosition(metaAccList[0]["_id"], "SELL", jsonRespObj["security"])
		#tdaAuthObj = initializeTDAAuthentication()
		#placeTDAOrder(tdaAuthObj, jsonRespObj["security"], "sell", 1)

	else: return "Error: Unknown JSON Keys"

	return ""

""" END FLASK APP ENDPOINT DEFINITIONS """

if __name__ == '__main__':
	print("Please execute this script by executing 'flask run' in the same directory as this file")
