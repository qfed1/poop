# -*- coding: utf-8 -*-
""" Calvara  """

import configparser

__name__ = "Calvara"
__version__ = "1.0.0"
__author__ = "Transaxi Labs LLC"
__author_email__ = "dev@transaxi.investments"
__copyright__ = "Copyright (c) 2022 Transaxi Labs LLC"

__verbose__ = False

__config__ = configparser.ConfigParser()
__config__.read("./data/core.ini")

# Core Library
from .LogCore import LogCore
from .UtilCore import UtilCore

# Broker APIs
from .BrokerCore import BrokerCore
from .TDACore import TDACore
from .MetaCore import MetaCore