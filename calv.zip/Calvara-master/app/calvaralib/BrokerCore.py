import calvaralib
import tda, json

class BrokerCore(object):
	"""
		calvaralib | BrokerCore
	"""

	def __init__(self, *args, **kwargs):
		self.isBrokerCoreWorking = True

		# Core Modules
		self.fllogger = calvaralib.LogCore()
		self.flutil = calvaralib.UtilCore()

		# Broker Modules
		self.fltda = calvaralib.TDACore()

	# TDA API Authentication
	def initializeTDAAuthentication():
		tdaAuthObj = None
		flutil.print_info("Logging into TD Ameritrade..")
		try: tdaAuthObj = tda.auth.client_from_token_file(calvaralib.__config__["TDA_API"]["TDA_TOKEN_FILE"], calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"])
		except Exception: tdaAuthObj = tda.auth.client_from_manual_flow(calvaralib.__config__["TDA_API"]["TDA_CONSUMER_KEY"], calvaralib.__config__["TDA_API"]["TDA_REDIRECT_URL"], calvaralib.__config__["TDA_API"]["TDA_TOKEN_FILE"])
		flutil.print_success("Successfully Authenticated!\n")
		return tdaAuthObj

	def placeTDAOrder(tdaAuthObj, tarSecurity, tradeDirection, tradeQuantity):
		accountListObj = json.loads(tdaAuthObj.get_accounts().text)

		flutil.print_info("")
		placedOrderObj = None
		if tradeDirection == "buy": placedOrderObj = tdaAuthObj.place_order(accountListObj[0]["securitiesAccount"]["accountId"], tda.orders.equities.equity_buy_market(tarSecurity, tradeQuantity))
		elif tradeDirection == "sell": placedOrderObj = tdaAuthObj.place_order(accountListObj[0]["securitiesAccount"]["accountId"], tda.orders.equities.equity_sell_market(tarSecurity, tradeQuantity))
		else: flutil.print_error("Trade direction is unknown. Please only use 'buy' or 'sell'!")

		placedOrderData = json.loads(placedOrderObj.text)
		# {"error": "Your buying power will be below zero ($187.75) if this order is accepted., OrderId: 5738614225"}

		if placedOrderObj.status_code == 200:
			print(placedOrderObj.text) # this will need to be debugged in the future to see what a successful trade inquiry looks like
			fllogger.logTradeAction("open", tradeDirection, jsonRespObj["security"], tradeQuantity)
		elif placedOrderObj.status_code == 400:
			errorObj = placedOrderData["error"].split(", ")
			flutil.print_warning("{0} failed to execute\n{1}".format(errorObj[1], errorObj[0]))
			fllogger.logTradeAction("error", tradeDirection, jsonRespObj["security"], tradeQuantity)