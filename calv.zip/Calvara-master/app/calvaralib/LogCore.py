import calvaralib
import sys, json, datetime

class LogCore(object):
	"""
		CalvaraLib | LogCore
	"""

	def __init__(self, *args, **kwargs):
		self.flutil = calvaralib.UtilCore()
		self.logFileLocation = calvaralib.__config__["CALVARA"]["CVA_TRADE_LOG"]

	def logTradeAction(self, tradeOrderID, tradeAction, tradeDirection, tradeSecurity, tradeQuantity):
		""" LogCore => logTradeAction()

		Log Syntax

		{
			"activeTrades": [
				{
					"tradeOrderID": Order ID (from Broker)
					"openTimestamp": Current Date
					"closeTimestamp": None
					"tradeDirection": "buy" or "sell"
					"tradeSecurity": Security Symbol (ex: NVDA)
					"tradeQuantity": Quantity of Securities [int]
				},
				...
			],
			"pastTrades": [
				{
					"tradeOrderID": "0123456789",
					"openTimestamp": "2022-08-02",
					"closeTimestamp": "2022-08-16",
					"tradeDirection": "buy",
					"tradeSecurity": "NVDA",
					"tradeQuantity": 5
				},
				...
			],
			"failedTrades": [
				{
					...
				}
			]
		}

		"""
		tradeLogObj = None
		with open(self.logFileLocation, "r") as tradeLog:
			tradeLogObj = json.loads(tradeLog.read())

		with open(self.logFileLocation, "a") as logFile:
			# clean log as we're going to append new data
			logFile.truncate(0)

		logPayload = {
			"tradeOrderID": tradeOrderID,
			"openTimestamp": str(datetime.date.today()),
			"closeTimestamp": str(datetime.date.today()) if tradeAction == "close" else None,
			"tradeDirection": tradeDirection,
			"tradeSecurity": tradeSecurity,
			"tradeQuantity": tradeQuantity
		}

		self.flutil.print_debug("Initialized Trade Payload Log [{0}]\n{1}".format(tradeAction, json.dumps(logPayload)))

		if tradeAction == "test": pass
		elif tradeAction == "open": tradeLogObj["activeTrades"].append(logPayload)
		elif tradeAction == "close": tradeLogObj["pastTrades"].append(logPayload)
		elif tradeAction == "error": tradeLogObj["failedTrades"].append(logPayload)
		else: self.flutil.print_warning("Unrecognized Trade Action. Only 'open' and 'close' are available!")

		# Finalize Logfile
		with open(self.logFileLocation, "w") as tradeLog:
			tradeLog.write(json.dumps(tradeLogObj))