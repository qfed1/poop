import calvaralib
import sys, colorama

class UtilCore(object):
	"""
		CalvaraLib | UtilCore
	"""

	def __init__(self, *args, **kwargs):
		self.isUtilCoreWorking = True

	# Text Coloring Properties
	def print_success(self, string): print(f'{colorama.Style.BRIGHT}{colorama.Fore.GREEN}{colorama.Style.BRIGHT}[+] ' + string + f'{colorama.Style.RESET_ALL}')
	def print_warning(self, string): print(f'{colorama.Style.BRIGHT}{colorama.Fore.YELLOW}[=] ' + string + f'{colorama.Style.RESET_ALL}')
	def print_error(self, string): print(f'{colorama.Style.BRIGHT}{colorama.Fore.RED}[-] ' + string + f'{colorama.Style.RESET_ALL}'); sys.exit(0)
	def print_info(self, string): print(f'{colorama.Style.BRIGHT}{colorama.Fore.CYAN}[i] ' + string + f'{colorama.Style.RESET_ALL}')
	def print_debug(self, string):
		if calvaralib.__verbose__: print(f'{colorama.Style.BRIGHT}{colorama.Fore.MAGENTA}[#] ' + string + f'{colorama.Style.RESET_ALL}')
	def print_divider(self): print('\n' + ('-' * 25) + '\n')
